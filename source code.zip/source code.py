import os
import cv2
import math
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from pytictoc import TicToc
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_selection import mutual_info_classif
from sklearn.preprocessing import KBinsDiscretizer
from sklearn.metrics import mean_absolute_error, mean_squared_log_error, \
    median_absolute_error
from sklearn.metrics import   max_error, mean_absolute_percentage_error
from sklearn.metrics import mean_squared_error as mse
from tensorflow.python.keras.models import load_model
from LeNet import LeNet_
from LinkNet import linknet, linknet_fed, Implinknet_fed, AdaptiveAttentionLpPooling, ParametricAttentionBatchNorm
from comparision import AblationStudy
from other import result
from other.norm_ import *
from math import sqrt
import xgboost as xgb
import tensorflow as tf
from tensorflow.python.keras.models import Sequential
from tensorflow.python.keras.layers import Input, Conv1D, MaxPooling1D, AveragePooling1D, Flatten, Dense, Dropout, \
    BatchNormalization, LeakyReLU, Concatenate, LSTM, Bidirectional, SimpleRNN, Lambda
from numpy import array as ar
from EfficientNet import efficient_net


def FullAnalysis():
    os.makedirs('pre_evaluated/', exist_ok=True)
    ReadDataset=True
    if ReadDataset:
        df= pd.read_csv(f'Final Crop Yield Dataset.csv')
        le = LabelEncoder()
        # Fit and transform to numeric labels
        df.iloc[:, 0] = le.fit_transform(df.iloc[:, 0])
        df.iloc[:, 1] = le.fit_transform(df.iloc[:, 1])
        df.iloc[:, 3] = le.fit_transform(df.iloc[:, 3])
        df.iloc[:, 4] = le.fit_transform(df.iloc[:, 4])
        Data = df.values
        Tar = Data[:,13]
        Data = Data[:,0:13]
        Data = np.nan_to_num(Data, nan=0.0, posinf=0.0, neginf=0.0)
        Tar = np.nan_to_num(Tar, nan=0.0, posinf=0.0, neginf=0.0)
        Tar = Tar.astype(int)
        np.save(f'pre_evaluated/Data',np.array(Data))
        np.save(f'pre_evaluated/Tar', np.array(Tar))

    Preprocessing=True
    # Define your normalization functions
    def min_max_normalization(Sk):
        min_val = np.min(Sk)
        max_val = np.max(Sk)
        if max_val == min_val:
            return np.zeros_like(Sk)
        return (Sk - min_val) / (max_val - min_val)

    def weighted_robust_min_max(x, epsilon=1e-6):
        # Step 1: median and MAD
        med = np.median(x)
        mad = np.median(np.abs(x - med))
        # Step 2: robust z-score
        x1 = (x - med) / (mad + epsilon)
        # Step 3: log-tanh nonlinear compression
        x2 = np.sign(x1) * np.tanh(np.log(1 + np.abs(x1)))
        # Step 4: calculate weights (inversely proportional to absolute deviations)
        deviations = np.abs(x - med) + epsilon
        w_raw = 1 / deviations
        w = w_raw / np.sum(w_raw)  # normalized weights
        # Step 5: weighted min-max normalization to [0,1]
        weighted_x2 = x2 * w
        x3 = (weighted_x2 - np.min(weighted_x2)) / (np.max(weighted_x2) - np.min(weighted_x2) + epsilon)
        return x3

    if Preprocessing:
        # Load data and labels
        Data = np.load('pre_evaluated/Data.npy', allow_pickle=True)
        Data = np.array(Data, dtype=float)  # ensure numeric

        preData = weighted_robust_min_max(Data)
        np.save(f'pre_evaluated/PreData.npy', preData)

        cpreData = min_max_normalization(Data)
        np.save(f'pre_evaluated/CPreData.npy', cpreData)

    FeatureExtraction = False
    # -----------------------------
    # Shannon entropy
    # -----------------------------
    def entropy(prob_dist, base=2, epsilon=1e-10):
        """Compute Shannon entropy for a probability distribution."""
        prob_dist = np.array(prob_dist, dtype=float)
        prob_dist = prob_dist[prob_dist > 0]  # ignore zero probabilities
        return -np.sum(prob_dist * np.log(prob_dist + epsilon) / np.log(base))
    # -----------------------------
    # Classical mutual information
    # -----------------------------
    def mutual_information(joint_prob, base=2, epsilon=1e-10):
        joint_prob = np.array(joint_prob, dtype=float)
        joint_prob = joint_prob / (np.sum(joint_prob) + epsilon)  # normalize
        px = np.sum(joint_prob, axis=1)
        py = np.sum(joint_prob, axis=0)
        mi = 0
        for i in range(joint_prob.shape[0]):
            for j in range(joint_prob.shape[1]):
                pxy = joint_prob[i, j]
                if pxy > 0:
                    mi += pxy * np.log(pxy / (px[i] * py[j] + epsilon) + epsilon) / np.log(base)
        return mi
    # -----------------------------
    # Nonlinear weighting
    # -----------------------------
    def tanh_weight(Hx, Hy, epsilon=1e-10):
        return np.tanh(Hx / (Hy + epsilon))
    # -----------------------------
    # Regularization term
    # -----------------------------
    def regularization(Hx, Hy, lam=0.01, epsilon=1e-10):
        numerator = (Hx - Hy) ** 2
        denominator = Hx ** 2 + Hy ** 2 + epsilon
        return lam * numerator / denominator
    # -----------------------------
    # Ensemble / modified entropy
    # -----------------------------
    def modified_entropy(mass_func, focal_sizes, epsilon=1e-10):
        """Compute ensemble entropy from mass function and focal element sizes."""
        E = 0
        for mA, sizeA in zip(mass_func, focal_sizes):
            if mA > 0 and sizeA > 0:
                term = (mA + np.exp(sizeA - 1)) / max(2 * (2 ** sizeA - 1), epsilon)
                term *= np.exp(sizeA - 1)
                E += -mA * np.log2(max(term, epsilon))
        return E
    # -----------------------------
    # Modified Improved Mutual Information
    # -----------------------------
    def modified_improved_MI(joint_prob, px, py, mass_func_x, sizeA_x, mass_func_y, sizeA_y, lam=0.01, epsilon=1e-10):
        # Step 1: Classical MI
        MI = mutual_information(joint_prob, epsilon=epsilon)

        # Step 2: Entropies
        Hx = entropy(px, epsilon=epsilon)
        Hy = modified_entropy(mass_func_y, sizeA_y, epsilon=epsilon)

        # Step 3: Ensemble entropy for X
        Ex = modified_entropy(mass_func_x, sizeA_x, epsilon=epsilon)

        # Step 4: Nonlinear weight
        W = tanh_weight(Hx, Hy, epsilon=epsilon)

        # Step 5: Regularization
        R = regularization(Hx, Hy, lam=lam, epsilon=epsilon)

        # Step 6: Mean focal element size (approximation)
        mean_A = np.mean(sizeA_x) if len(sizeA_x) > 0 else 1

        # Step 7: Combine terms
        numerator = Hx * Ex + Hy
        denominator = Hx ** 2 + Hy ** 2 + epsilon
        main_term = Hx * 2 ** mean_A + Ex

        M_IMI = MI + W * ((numerator / denominator) * main_term - R)
        return M_IMI
    # -----------------------------
    # Entropy function
    # -----------------------------
    def conv_entropy(image):
        """Calculates the entropy of a grayscale image.

        Args:
            image: A 2D numpy array representing the grayscale image.

        Returns:
            The entropy of the image. Returns None if image is not grayscale.
        """
        if len(image.shape) != 2:
            print("Error: Input image must be grayscale.")
            return None
        histogram = cv2.calcHist([image], [0], None, [256], [0, 256]).flatten()
        total_pixels = image.shape[0] * image.shape[1]
        probabilities = histogram / total_pixels
        probabilities = probabilities[probabilities > 0]  # avoid log(0)
        entropy = -np.sum(probabilities * np.log2(probabilities))
        return entropy
    # -----------------------------
    # Statistical features
    # -----------------------------
    def Statistical_Features(x):
        min_val = np.min(x)
        max_val = np.max(x)
        std_val = np.std(x)
        median_val = np.median(x)
        mean_val = np.mean(x)
        variance_val = np.var(x)
        return np.array([min_val, max_val, std_val, median_val, mean_val, variance_val])
    # -----------------------------
    # Feature extraction
    # -----------------------------
    if FeatureExtraction:
        statfeat_list, ent_list = [], []
        Data = np.load('pre_evaluated/PreData.npy', allow_pickle=True)
        lab = np.load('pre_evaluated/Tar.npy', allow_pickle=True)

        for img in Data:
            # Ensure grayscale
            img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if len(img.shape) == 3 else img

            # Statistical features
            statfeat_list.append(Statistical_Features(img_gray))

            # Entropy feature
            ent_value = conv_entropy(img_gray)
            ent_list.append(np.array([ent_value]))

        # Mutual Information (flatten images)
        # Flatten the data
        flat_data = Data.reshape(len(Data), -1).astype(np.float64)

        # Replace NaN and Inf in features
        flat_data = np.nan_to_num(flat_data, nan=0.0, posinf=0.0, neginf=0.0)

        # Ensure labels are finite and integer type
        lab = np.nan_to_num(lab, nan=0.0, posinf=0.0, neginf=0.0)
        lab = lab.astype(int)

        # Compute mutual information
        mi_score = mutual_info_classif(flat_data, lab)
        # Select top 5 features
        feature_index = np.argsort(mi_score)[-5:]
        MI_feat = flat_data[:, feature_index]

        # Improved Mutual Information (flatten images)
        num_features = flat_data.shape[1]
        mi_scores = np.zeros(num_features)
        # Discretize data for joint histogram calculation
        discretizer = KBinsDiscretizer(n_bins=10, encode='ordinal', strategy='uniform')
        flat_data_disc = discretizer.fit_transform(flat_data)

        for f in range(num_features):
            feature_vals = flat_data_disc[:, f]
            unique_feat = np.unique(feature_vals)
            unique_lab = np.unique(lab)

            joint_hist = np.zeros((len(unique_feat), len(unique_lab)))
            feat_map = {v: i for i, v in enumerate(unique_feat)}
            lab_map = {v: i for i, v in enumerate(unique_lab)}

            for val, lbl in zip(feature_vals, lab):
                i = feat_map[val]
                j = lab_map[lbl]
                joint_hist[i, j] += 1

            joint_prob = joint_hist / np.sum(joint_hist)
            px = np.sum(joint_prob, axis=1)
            py = np.sum(joint_prob, axis=0)

            mass_func_x = px
            sizeA_x = np.ones_like(px)
            mass_func_y = py
            sizeA_y = np.ones_like(py)

            mi_scores[f] = modified_improved_MI(joint_prob, px, py, mass_func_x, sizeA_x, mass_func_y, sizeA_y)

        # Select top 5 features
        feature_index = np.argsort(mi_scores)[-5:]
        IMI_feat = flat_data[:, feature_index]

        # Concatenate features: statistical + entropy + MI
        FVector = np.hstack([np.array(statfeat_list), np.array(ent_list), IMI_feat])
        CFVector = np.hstack([np.array(statfeat_list), np.array(ent_list), MI_feat])

        # Save features
        np.save("pre_evaluated/FVector.npy", FVector)
        np.save("pre_evaluated/CFVector.npy", CFVector)

        Data = np.load('pre_evaluated/CPreData.npy', allow_pickle=True)
        lab = np.load('pre_evaluated/Tar.npy', allow_pickle=True)

        for img in Data:
            # Ensure grayscale
            img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if len(img.shape) == 3 else img

            # Statistical features
            statfeat_list.append(Statistical_Features(img_gray))

            # Entropy feature
            ent_value = conv_entropy(img_gray)
            ent_list.append(np.array([ent_value]))

        # Mutual Information (flatten images)
        # Flatten the data
        flat_data = Data.reshape(len(Data), -1).astype(np.float64)

        # Replace NaN and Inf in features
        flat_data = np.nan_to_num(flat_data, nan=0.0, posinf=0.0, neginf=0.0)

        # Ensure labels are finite and integer type
        lab = np.nan_to_num(lab, nan=0.0, posinf=0.0, neginf=0.0)
        lab = lab.astype(int)


        # Improved Mutual Information (flatten images)
        num_features = flat_data.shape[1]
        mi_scores = np.zeros(num_features)
        # Discretize data for joint histogram calculation
        discretizer = KBinsDiscretizer(n_bins=10, encode='ordinal', strategy='uniform')
        flat_data_disc = discretizer.fit_transform(flat_data)

        for f in range(num_features):
            feature_vals = flat_data_disc[:, f]
            unique_feat = np.unique(feature_vals)
            unique_lab = np.unique(lab)

            joint_hist = np.zeros((len(unique_feat), len(unique_lab)))
            feat_map = {v: i for i, v in enumerate(unique_feat)}
            lab_map = {v: i for i, v in enumerate(unique_lab)}

            for val, lbl in zip(feature_vals, lab):
                i = feat_map[val]
                j = lab_map[lbl]
                joint_hist[i, j] += 1

            joint_prob = joint_hist / np.sum(joint_hist)
            px = np.sum(joint_prob, axis=1)
            py = np.sum(joint_prob, axis=0)

            mass_func_x = px
            sizeA_x = np.ones_like(px)
            mass_func_y = py
            sizeA_y = np.ones_like(py)

            mi_scores[f] = modified_improved_MI(joint_prob, px, py, mass_func_x, sizeA_x, mass_func_y, sizeA_y)

        # Select top 5 features
        feature_index = np.argsort(mi_scores)[-5:]
        IMI_feat = flat_data[:, feature_index]

        CPFVector = np.hstack([np.array(statfeat_list), np.array(ent_list), IMI_feat])
        np.save("pre_evaluated/CPFVector.npy", CPFVector)

        Data = np.load('pre_evaluated/Data.npy', allow_pickle=True)
        lab = np.load('pre_evaluated/Tar.npy', allow_pickle=True)

        for img in Data:
            # Ensure grayscale
            img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if len(img.shape) == 3 else img

            # Statistical features
            statfeat_list.append(Statistical_Features(img_gray))

            # Entropy feature
            ent_value = conv_entropy(img_gray)
            ent_list.append(np.array([ent_value]))

        # Mutual Information (flatten images)
        # Flatten the data
        flat_data = Data.reshape(len(Data), -1).astype(np.float64)

        # Replace NaN and Inf in features
        flat_data = np.nan_to_num(flat_data, nan=0.0, posinf=0.0, neginf=0.0)

        # Ensure labels are finite and integer type
        lab = np.nan_to_num(lab, nan=0.0, posinf=0.0, neginf=0.0)
        lab = lab.astype(int)


        # Improved Mutual Information (flatten images)
        num_features = flat_data.shape[1]
        mi_scores = np.zeros(num_features)
        # Discretize data for joint histogram calculation
        discretizer = KBinsDiscretizer(n_bins=10, encode='ordinal', strategy='uniform')
        flat_data_disc = discretizer.fit_transform(flat_data)

        for f in range(num_features):
            feature_vals = flat_data_disc[:, f]
            unique_feat = np.unique(feature_vals)
            unique_lab = np.unique(lab)

            joint_hist = np.zeros((len(unique_feat), len(unique_lab)))
            feat_map = {v: i for i, v in enumerate(unique_feat)}
            lab_map = {v: i for i, v in enumerate(unique_lab)}

            for val, lbl in zip(feature_vals, lab):
                i = feat_map[val]
                j = lab_map[lbl]
                joint_hist[i, j] += 1

            joint_prob = joint_hist / np.sum(joint_hist)
            px = np.sum(joint_prob, axis=1)
            py = np.sum(joint_prob, axis=0)

            mass_func_x = px
            sizeA_x = np.ones_like(px)
            mass_func_y = py
            sizeA_y = np.ones_like(py)

            mi_scores[f] = modified_improved_MI(joint_prob, px, py, mass_func_x, sizeA_x, mass_func_y, sizeA_y)

        # Select top 5 features
        feature_index = np.argsort(mi_scores)[-5:]
        IMI_feat = flat_data[:, feature_index]

        WPFVector = np.hstack([np.array(statfeat_list), np.array(ent_list), IMI_feat])
        np.save("pre_evaluated/WPFVector.npy", WPFVector)


    Prediction=False

    def rrmse(y_true, y_pred):
        """
        Calculate the Relative Root Mean Squared Error (RRMSE).

        Parameters:
        y_true (array-like): Array of true values.
        y_pred (array-like): Array of predicted values.

        Returns:
        float: RRMSE value.
        """
        numerator = np.sqrt(np.mean((y_true - y_pred) ** 2))
        denominator = np.mean(y_true)
        return numerator / denominator

    def errorMeasure(Y_test, pred):

        MSE = mse(Y_test.reshape(-1, 1), pred)
        RMSE = sqrt(MSE)
        MAE = mean_absolute_error(Y_test, pred)
        MSLE = mean_squared_log_error(Y_test, pred.__abs__())
        MEAE = median_absolute_error(Y_test, pred)
        MedAE = rrmse(Y_test.flatten().__abs__(),
                      pred.flatten().__abs__())
        ME = max_error(Y_test.flatten().__abs__(), pred.flatten().__abs__())
        MAPE = mean_absolute_percentage_error(Y_test, pred)
        MdAPE = median_absolute_percentage_error(Y_test, pred)
        metrics = np.array([ME,MSE, RMSE, MAE, MSLE,MEAE,MedAE,MAPE, MedAE, MdAPE])
        return metrics

    def local_training_model():
        imp_lnet = Implinknet_fed(X_train, Y_train, X_test, Y_test)
        return imp_lnet

    def master_model(run=False):
        import keras
        learn_percent, learning_percentage = [0.6, 0.7, 0.8, 0.9], ['60', '70', '80', '90']
        for lp, lpstr in zip(learn_percent, learning_percentage):
            # Merge and Aggregate
            if run:
                # Local trained models
                custom_layers = {
                    'AdaptiveAttentionLpPooling': AdaptiveAttentionLpPooling,
                    'ParametricAttentionBatchNorm': ParametricAttentionBatchNorm,
                }
                lnet_model1 = keras.models.load_model(f"pre_evaluated/saved_models/ILnet{0}{lpstr}.keras", custom_objects=custom_layers)               # Local trained model2
                lnet_model2 =  keras.models.load_model(f"pre_evaluated/saved_models/ILnet{1}{lpstr}.keras", custom_objects=custom_layers)
                lnet_model3 =  keras.models.load_model(f"pre_evaluated/saved_models/ILnet{2}{lpstr}.keras", custom_objects=custom_layers)
                lnet_model4 =  keras.models.load_model(f"pre_evaluated/saved_models/ILNet{3}{lpstr}.keras", custom_objects=custom_layers)
                lnet_model5 =  keras.models.load_model(f"pre_evaluated/saved_models/ILNet{4}{lpstr}.keras", custom_objects=custom_layers)
                lnet_model6 = keras.models.load_model(f"pre_evaluated/saved_models/ILNet{5}{lpstr}.keras", custom_objects=custom_layers)                # Local trained model2
                lnet_model7 =  keras.models.load_model(f"pre_evaluated/saved_models/ILNet{6}{lpstr}.keras", custom_objects=custom_layers)
                lnet_model8 =  keras.models.load_model(f"pre_evaluated/saved_models/ILNet{7}{lpstr}.keras", custom_objects=custom_layers)
                lnet_model9 =  keras.models.load_model(f"pre_evaluated/saved_models/ILNet{8}{lpstr}.keras", custom_objects=custom_layers)
                lnet_model10 =  keras.models.load_model(f"pre_evaluated/saved_models/ILNet{9}{lpstr}.keras", custom_objects=custom_layers)

                # Merge and Aggregate
                for i, layer1, layer2, layer3, layer4, layer5, layer6, layer7, layer8, layer9, layer10 in zip(range(len(lnet_model1.layers)), lnet_model1.layers, lnet_model2.layers, lnet_model3.layers,
                                                                  lnet_model4.layers, lnet_model5.layers,lnet_model6.layers, lnet_model7.layers,lnet_model8.layers, lnet_model9.layers, lnet_model10.layers):
                    layer2.set_weights(layer1.get_weights())
                    layer3.set_weights(layer2.get_weights())
                    layer4.set_weights(layer3.get_weights())
                    layer5.set_weights(layer4.get_weights())
                    layer6.set_weights(layer5.get_weights())
                    layer7.set_weights(layer6.get_weights())
                    layer8.set_weights(layer7.get_weights())
                    layer9.set_weights(layer8.get_weights())
                    lnet_model10.layers[i].set_weights(layer9.get_weights())
                masteripcnn = lnet_model10
                masteripcnn.save(f'net_masterilnet{lpstr}.keras')

    def reshape_(data):
        # Check for None
        if data is None:
            raise ValueError("Input `data` is None. Make sure it's loaded correctly.")
        # Ensure data is numpy array
        data = np.asarray(data, dtype=np.float32)
        # Scale to [0, 255]
        data_uint8 = (data * 255).astype(np.uint8)
        # Preallocate output array
        resized_data = np.zeros((len(data_uint8), 32, 32, 3), dtype=np.uint8)
        for i in range(len(data_uint8)):
            try:
                img = data_uint8[i]
                # Handle grayscale (2D) vs color (3D) cases
                if img.ndim == 2:
                    img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
                # Force reshape if wrong size
                if img.size != 32 * 32 * 3:
                    img = np.resize(img, (32, 32, 3))
                else:
                    img = img.reshape(32, 32, 3)

                # Final resize to enforce shape
                img_resized = cv2.resize(img, (32, 32))
                resized_data[i] = img_resized
            except Exception as e:
                print(f"Error reshaping image at index {i}: {e}")
                continue
        return resized_data

    def prop(lpstr):
        t = TicToc()
        t.tic()
        reget_flag = 0
        # Directory to save the network
        sav_folder = 'net_saved'
        if not os.path.exists(sav_folder):
            os.makedirs(sav_folder)
        # Name of the file to save the model
        sav_name = f'net_masterilnet{lpstr}.keras'
        import keras
        model = keras.models.load_model(sav_name)
        input_shape = (32, 32, 3)
        x_test_ = reshape_(X_test)  # Apply reshaping
        y_predict = model.predict(x_test_)
        predict = array(np.argmax(y_predict, axis=1),axis=0)
        predict =predict.reshape(-1, 1)
        metric = errorMeasure(Y_test, predict)
        t.toc()
        return metric, predict, t.tocvalue()

    def LNet():
        t = TicToc()
        t.tic()
        y_pred = LeNet_(X_train, Y_train, X_test, Y_test)
        metric = errorMeasure(Y_test, y_pred)
        t.toc()
        return metric, y_pred, t.tocvalue()

    def ENet():
        t = TicToc()
        t.tic()
        y_pred = efficient_net(X_train, Y_train, X_test, Y_test)
        metric = errorMeasure(Y_test, y_pred)
        t.toc()
        return metric, y_pred, t.tocvalue()

    def SNet():
        t = TicToc()
        t.tic()
        from Squeezenet import squeezenet
        y_pred = squeezenet(X_train, Y_train, X_test, Y_test)
        metric = errorMeasure(Y_test, y_pred)
        t.toc()
        return metric, y_pred, t.tocvalue()

    def Lstm():
        t = TicToc()
        t.tic()
        from LSTM import lstm
        predict = lstm(X_train, Y_train, X_test, Y_test)
        predict =predict.reshape(-1, 1)
        metric = errorMeasure(Y_test, predict)
        t.toc()
        return metric, predict, t.tocvalue()


    def stat_analysis_(xx):
        mn = np.mean(xx, axis=0).reshape(-1, 1)
        mdn = np.median(xx, axis=0).reshape(-1, 1)
        std_dev = np.std(xx, axis=0).reshape(-1, 1)
        min = np.min(xx, axis=0).reshape(-1, 1)
        mx = np.max(xx, axis=0).reshape(-1, 1)
        return np.concatenate((mn, mdn, std_dev, min, mx), axis=1)

    if Prediction:
        os.makedirs('pre_evaluated/saved_models/', exist_ok=True)
        Gen_LocalModel=False
        if Gen_LocalModel:
            prop_feat_ = np.load(f'pre_evaluated/saved/FVector.npy',allow_pickle=True)
            label_ = np.load(f'pre_evaluated/saved/Tar.npy',allow_pickle=True)
            # Local Training Model
            start,end=0,1000
            for hos in range(10):
                prop_feat = prop_feat_[start:end, :]
                label = label_[start:end]
                learn_percent, learning_percentage = [0.6, 0.7, 0.8, 0.9], ['60', '70', '80', '90']
                for lp, lpstr in zip(learn_percent, learning_percentage):
                    X_train, X_test, Y_train, Y_test = train_test_split(prop_feat, label, train_size=lp, random_state=0)
                    lnet = local_training_model()
                    lnet.save(f'pre_evaluated/saved_models/ILNet{hos}{lpstr}.keras')
                start = start + 1000
                end=end+1000

        # Master Model Creation
        master_model(run=False)

        feature = np.load('pre_evaluated/FVector.npy', allow_pickle=True)
        label = np.load(f'pre_evaluated/Tar.npy', allow_pickle=True)
        learn_percent, learning_percentage, learning_count = [0.6, 0.7, 0.8, 0.9], ['60', '70', '80', '90'], [0, 1, 2,3]

        feature = np.array(feature, dtype=np.float64)
        col_mean = np.nanmean(feature, axis=0)  # mean per column
        inds = np.where(np.isnan(feature))  # indices of NaN
        feature[inds] = np.take(col_mean, inds[1])  # replace NaN with column mean

        feature = (feature - np.min(feature, axis=0)) / (np.max(feature, axis=0) - np.min(feature, axis=0) + 1e-8)

        ln = len(set(label))
        true_lab, pred_label = [], []

        for lp, lpstr, ij in zip(learn_percent, learning_percentage, learning_count):

            X_train, X_test, Y_train, Y_test, = train_test_split(feature, label, train_size=lp,
                                                                 random_state=0)
            np.save('pre_evaluated/Y_test', Y_test);
            true_lab.append(Y_test)
            np.save('pre_evaluated/lp', lp)
            np.save(f'pre_evaluated/Y_test_{lpstr}', Y_test)
            result = [prop(lpstr),Base2(),Base1(),Lstm(),CNN(),LNet(), ENet(),SNet(), prop(lpstr)]
            perf = ar([result[i][0] for i in range(len(result))])
            perf = extract(perf, axis=[1])
            pred_label = np.concatenate([result[i][1].ravel() for i in range(len(result))])
            comtim = extract(np.array([result[i][2] for i in range(len(result))]), axis=[0])
            np.save(f'pre_evaluated/pred_label_{lpstr}', pred_label)
            clmn = ['ER-ETR', 'CNN-LSTM', 'LSTM', 'CNN', 'LeNet', 'EfficientNet', 'SqueezeNet', 'MPA-LN']
            indx = ['ME','MSE', 'RMSE', 'MAE', 'MSLE','MEAE','MAPE', 'MedAE', 'MdAPE']
            indx2 = ['computational time']
            comtim = np.array(comtim)
            globals()['df' + lpstr] = pd.DataFrame(perf.transpose(), columns=clmn, index=indx)
            globals()['df2' + lpstr] = pd.DataFrame(comtim.reshape(1, -1), columns=clmn, index=indx2)

        key = ['60', '70', '80', '90']
        frames = [df60, df70, df80, df90]
        frames2 = [df260, df270, df280, df290]
        df = pd.concat(frames, keys=key, axis=0)
        df2 = pd.concat(frames2, keys=key, axis=0)


    PlotResult=False
    def line_plot(X, clr=None, index=None, xlabel=None, ylabel=None, markers=None):
        br1 = np.arange(X.shape[0])  # x-axis points
        plt.figure(figsize=(12, 7))
        # Default markers if not provided
        if markers is None:
            markers = ['o', 's', '^', 'D', 'v', '*', 'P', 'X']
        for i in range(X.shape[1]):
            plt.plot(
                br1, X[:, i],
                color=clr[i] if clr else None,
                label=index[i] if index else None,
                linewidth=3,
                marker=markers[i % len(markers)],  # Cycle markers if more lines than markers
                markersize=12
            )
        plt.subplots_adjust(bottom=0.2)
        plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.3), fontsize=15, ncol=5)
        plt.xlabel(xlabel, weight='bold', size=17)
        plt.ylabel(ylabel, weight='bold', size=17)
        plt.xticks(br1, ['60', '70', '80', '90'], weight='bold', size=15)
        plt.yticks(weight='bold', size=15)
        plt.savefig(f'Results/{ylabel}.png', dpi=800)

    if PlotResult:
        # Create save directory if it doesn't exist
        save_dir = f'Results/FullAnalysis/'
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        colors = ['b', 'r', 'c', 'orange', 'tan', 'lime', 'tomato', 'tab:pink']
        comp = ['ER-ETR', 'CNN-LSTM', 'LSTM', 'CNN', 'LeNet', 'EfficientNet', 'SqueezeNet', 'MPA-LN']

        # Load and plot the results
        hatches = ['//', '..', '\\\\', 'oo', '--', '++', 'xx', '**', '||', '00']
        colors = ['blue', 'red', 'green', 'cyan', 'orange', 'tan', 'lime', 'tomato', 'pink', 'purple']
        column = ['Cross-window Transformer', 'Tabular Transformer', 'ER-ETR', 'CNN-LSTM', 'LSTM', 'CNN', 'LeNet',
                  'EfficientNet', 'SqueezeNet', 'MPA-LN']
        indx = ['MSE', 'RMSE', 'MAE', 'MSLE', 'MAPE', 'MedAE', 'MPL', 'MPD']


        plot_result = pd.read_csv(f'pre_evaluated/Comparision.csv', index_col=[0, 1])
        # Ablation study
        file_path = f'pre_evaluated/Ablation Study.csv'
        df = pd.read_csv(file_path, index_col=[0], header=[0])
        filtered_df = df[df['Training Data'] == 80]
        filtered_df.to_csv(f'{save_dir}/Ablation Study(80%).csv', index=False)

        # Save other CSV outputs
        state = pd.read_csv(f'pre_evaluated/statistics analysis.csv', header=0, names=column)
        state.to_csv(f'{save_dir}/Statistics analysis.csv')

        # Set grayscale style
        plt.style.use('grayscale')
        # Analysis plot
        for idx, jj in enumerate(indx):
            new_ = plot_result.loc[([60, 70, 80, 90], [jj]), :]
            new_.reset_index(drop=True, level=1, inplace=True)
            new = new_.values
            line_plot(new, clr=colors, index=column, xlabel='Training Data (%)',ylabel=jj.upper())


print('0--full_analysis  1--Plot')
prompt = int(input("Enter your request(0-1) :"))
if prompt == 0:
    FullAnalysis()
elif prompt == 1:
    result.result()