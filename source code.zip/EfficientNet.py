# import efficientnet.keras as efn
from tensorflow.keras.applications import efficientnet as efn
from tensorflow.python.keras.models import load_model

from other.norm_ import *
####res
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import logging
logging.getLogger('tensorflow').disabled = True
import warnings
warnings.filterwarnings("ignore")
sq1x1 = "squeeze1x1"
exp1x1 = "expand1x1"
exp3x3 = "expand3x3"
relu = "relu_"
import numpy as np


def efficient_net(x_train,  y_train,x_test, y_test):
    unique_name = f'net_saved/Enet'  # Python equivalent of num2str(k)
    reget_flag = 0
    # Directory to save the network
    sav_folder = 'net_saved'
    if not os.path.exists(sav_folder):
        os.makedirs(sav_folder)
    # Name of the file to save the model
    sav_name = f'net_saved/Enet.h5'
    # Check if the file exists or if reget_flag is set to 1
    if not os.path.exists(os.path.join(sav_name)) or reget_flag == 1:
        x_train,x_test=np.array(x_train),np.array(x_test)
        y_train,y_test=np.array(y_train),np.array(y_test)
        parameters = []
        batch_size = 32
        epochs = 1
        data_augmentation = True
        loss = 'mean_squared_error'
        learning = 0.0001
        eps = 1e-08
        beta = 0.966
        betaa = 0.999
        optimizer = 'adam'
        subtract_pixel_mean = True
        n = 3
        version = 1
        if version == 1:
            depth = n * 6 + 2
        elif version == 2:
            depth = n * 9 + 2
        predict = []
        for i in range(len(y_train)): predict.append(y_train[i])
        model_type = 'ResNet % dv % d' % (depth, version)
        input_shape = x_train.shape[1:]
        y_train = y_train.astype('int')
        x_train = x_train.astype('float32') / 255
        x_test = x_test.astype('float32') / 255
        y_test = y_test.astype('int')
        def lr_schedule(epoch):
            lr = 0.25
            if epoch > 180:
                lr *= 0.5e-3
            elif epoch > 160:
                lr *= 1e-3
            elif epoch > 120:
                lr *= 1e-2
            elif epoch > 80:
                lr *= 1e-1
            return lr
    # ####################### efficientnet5o ############################
        model = efn.EfficientNetB0(weights=None, include_top=False, classes=107)
        # model.summary()
        optimizer = Adam(lr=0.0001, beta_1=0.9, beta_2=0.999, epsilon=1e-08)
        model.compile(optimizer='adam',
                      loss='mean_squared_error',
                      metrics=['mean_absolute_error'])
        aa = x_train.shape
        x_train_n = np.resize(x_train, (aa[0], 32, 32, 3))
        aa = y_train.shape
        y_train_n = np.resize(y_train, (aa[0], 1, 1, 1280))
        model.fit(x_train_n, y_train_n, batch_size=batch_size, epochs=1, verbose=0)
        eff = model.get_weights()
        model.set_weights(eff)
        aa = x_test.shape
        x_test_n = np.resize(x_test, (aa[0], 32, 32, 3))
        pred = model.predict(x_test_n)
        pred_n = np.resize(pred, (aa[0]))
        pred1 = pred_n
        model.summary()
        model.save(sav_name)
        return pred1
    else:
        x_train,x_test=np.array(x_train),np.array(x_test)
        y_train,y_test=np.array(y_train),np.array(y_test)
        parameters = []
        batch_size = 32
        epochs = 1
        data_augmentation = True
        loss = 'mean_squared_error'
        learning = 0.0001
        eps = 1e-08
        beta = 0.966
        betaa = 0.999
        optimizer = 'adam'
        subtract_pixel_mean = True
        n = 3
        version = 1
        if version == 1:
            depth = n * 6 + 2
        elif version == 2:
            depth = n * 9 + 2
        predict = []
        for i in range(len(y_train)): predict.append(y_train[i])
        model_type = 'ResNet % dv % d' % (depth, version)
        input_shape = x_train.shape[1:]
        y_train = y_train.astype('int')
        x_train = x_train.astype('float32') / 255
        x_test = x_test.astype('float32') / 255
        y_test = y_test.astype('int')
        model = load_model(sav_name)
        eff = model.get_weights()
        model.set_weights(eff)
        aa = x_test.shape
        x_test_n = np.resize(x_test, (aa[0], 32, 32, 3))
        pred = model.predict(x_test_n)
        pred_n = np.resize(pred, (aa[0]))
        pred1 = pred_n
        return pred1