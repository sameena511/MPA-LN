import os
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv1D, MaxPooling1D, Flatten
from tensorflow.keras.layers import Conv2D, MaxPool2D, GlobalAveragePooling2D, Dropout
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Concatenate, Add, Input, Dense, Layer
from other.Confusion_matrix import *
from tensorflow.keras.utils import to_categorical
from other.norm_ import *
from tensorflow.python.keras.models import load_model

one = (1, 1)
two = (2, 2)
three = (3, 3)
five = (5, 5)
seven = (7, 7)
thirteen = (13, 13)
rn = 1
def squeezenet(X_train, Y_train, X_test, Y_test):

    class FireModule(object):
        """
        Fire Module computed as per the SqueezeNet paper
        """

        def __init__(self, layer_number: int, activation: str, kernel_initializer: str) -> None:
            """
            Constructor

            Arguments:
              layer_number       : Index of the Fire Module
              activation         : Activation to be used
              kernel_initializer : Kernel Weight Initialization technique

            Returns:
              None
            """

            self.layer_number = layer_number
            self.activation = activation
            self.kernel_initializer = kernel_initializer

        def build_module(self, fire_input: Layer) -> Layer:
            """
            Build the SqueezeNet

            Arguments:
              fire_input       : Input to Fire Module

            Returns:
              model            : SqueezeNet
            """

            global one, three, five

            output_size = 128 * (1 + (self.layer_number // 2))

            squeeze_1x1_filters = 16 * (1 + (self.layer_number // 2))
            expand_1x1_filters = expand_3x3_filters = output_size // 2

            squeeze_1x1 = Conv2D(name=f'fire_{self.layer_number + 2}_squeeze_1x1',
                                 filters=squeeze_1x1_filters, kernel_size=one, strides=1, padding='valid',
                                 activation=self.activation,
                                 kernel_initializer=self.kernel_initializer)(fire_input)
            expand_1x1 = Conv2D(name=f'fire_{self.layer_number + 2}_expand_1x1',
                                filters=expand_1x1_filters, kernel_size=one, strides=1, padding='valid',
                                activation=self.activation,
                                kernel_initializer=self.kernel_initializer)(squeeze_1x1)
            expand_3x3 = Conv2D(name=f'fire_{self.layer_number + 2}_expand_3x3',
                                filters=expand_3x3_filters, kernel_size=three, strides=1, padding='same',
                                activation=self.activation,
                                kernel_initializer=self.kernel_initializer)(squeeze_1x1)

            fire = Concatenate(name=f'fire_{self.layer_number + 2}')([expand_1x1, expand_3x3])

            return fire

    class SqueezeNet(object):
        """
        SqueezeNet Architecture
        """

        def __init__(self, activation: str = 'relu', kernel_initializer: str = 'glorot_uniform') -> None:
            """
            Constructor

            Arguments:
              activation         : Activation to be used
              kernel_initializer : Kernel Weight Initialization technique

            Returns:
              None
            """

            self.activation = activation
            self.kernel_initializer = kernel_initializer

        def vanilla_model(self, input_shape: tuple = (32, 32, 3), n_classes: int = 2) -> None:
            """
            Vanilla Implementation of SqueezeNet

            Arguments:
              input_shape         : Input Shape of the images
              n_classes           : Number of output classes

            Returns:
              None
            """

            inp = Input(shape=input_shape, name='Input')

            # Conv1 Layer
            conv_1 = Conv2D(name="Conv_1",
                            filters=96, kernel_size=seven, strides=2, padding='same', activation=self.activation,
                            kernel_initializer=self.kernel_initializer)(inp)
            maxpool_1 = MaxPool2D(name="MaxPool_1",
                                  pool_size=three, strides=2)(conv_1)

            # Fire 2-4
            fire_2 = FireModule(layer_number=0, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(maxpool_1)
            fire_3 = FireModule(layer_number=1, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(fire_2)
            fire_4 = FireModule(layer_number=2, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(fire_3)

            # Max Pool after Fire4 Module
            maxpool_2 = MaxPool2D(name="MaxPool_2",
                                  pool_size=three, strides=2)(fire_4)

            # Fire 5-8
            fire_5 = FireModule(layer_number=3, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(maxpool_2)
            fire_6 = FireModule(layer_number=4, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(fire_5)
            fire_7 = FireModule(layer_number=5, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(fire_6)
            fire_8 = FireModule(layer_number=6, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(fire_7)

            # Max Pool after Fire8 Module
            maxpool_3 = MaxPool2D(name="MaxPool_3",
                                  pool_size=three, strides=2)(fire_8)

            fire_9 = FireModule(layer_number=7, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(maxpool_3)

            # Dropout
            dropout = Dropout(0.5, name="Dropout")(fire_9)

            # Conv10 layer
            conv_10 = Conv2D(name="Conv_10",
                             filters=1000, kernel_size=one, strides=1, padding='valid', activation=self.activation,
                             kernel_initializer=self.kernel_initializer)(dropout)
            gap_11 = GlobalAveragePooling2D()(conv_10)

            # Add Dense(n_classes) and ouput == Dense layer
            out = Dense(1, activation='linear')(gap_11)

            self.model = Model(inputs=inp, outputs=out)

        def bypass_model(self, input_shape: tuple = (32, 32, 3), n_classes: int = 2) -> None:
            """
            Residual Inspired Bypass Implementation of SqueezeNet

            Arguments:
              input_shape         : Input Shape of the images
              n_classes           : Number of output classes

            Returns:
              None
            """

            inp = Input(shape=input_shape, name='Input')

            # Conv1 Layer
            conv_1 = Conv2D(name="Conv_1",
                            filters=96, kernel_size=seven, strides=2, padding='same', activation=self.activation,
                            kernel_initializer=self.kernel_initializer)(inp)
            maxpool_1 = MaxPool2D(name="MaxPool_1",
                                  pool_size=three, strides=2)(conv_1)

            # Fire 2-4
            fire_2 = FireModule(layer_number=0, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(maxpool_1)
            fire_3 = FireModule(layer_number=1, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(fire_2)
            bypass_1 = Add(name="Bypass_1")([fire_2, fire_3])
            fire_4 = FireModule(layer_number=2, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(bypass_1)

            # Max Pool after Fire4 Module
            maxpool_2 = MaxPool2D(name="MaxPool_2",
                                  pool_size=three, strides=2)(fire_4)

            # Fire 5-8
            fire_5 = FireModule(layer_number=3, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(maxpool_2)
            bypass_2 = Add(name="Bypass_2")([maxpool_2, fire_5])
            fire_6 = FireModule(layer_number=4, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(bypass_2)
            fire_7 = FireModule(layer_number=5, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(fire_6)
            bypass_3 = Add(name="Bypass_3")([fire_6, fire_7])
            fire_8 = FireModule(layer_number=6, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(bypass_3)

            # Max Pool after Fire8 Module
            maxpool_3 = MaxPool2D(name="MaxPool_3",
                                  pool_size=three, strides=2)(fire_8)

            fire_9 = FireModule(layer_number=7, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(maxpool_3)
            bypass_4 = Add(name="Bypass_4")([maxpool_3, fire_9])

            # Dropout
            dropout = Dropout(0.5, name="Dropout")(bypass_4)

            # Conv10 layer
            conv_10 = Conv2D(name="Conv_10",
                             filters=1000, kernel_size=one, strides=1, padding='valid', activation=self.activation,
                             kernel_initializer=self.kernel_initializer)(dropout)
            gap_11 = GlobalAveragePooling2D()(conv_10)

            out = Dense(4, activation='softmax')(gap_11)

            self.model = Model(inputs=inp, outputs=out)

        def build_model(self, input_shape: tuple = (32, 32, 3), n_classes: int = 4, choice: str = 'vanilla') -> Model:
            """
            Build SqueezeNet

            Arguments:
              input_shape         : Input Shape of the images
              n_classes           : Number of output classes
              choice              : Type of architecture (vanilla/bypass)
            Returns:
              model               : SqueezeNet Model
            """

            if choice == "vanilla":
                self.vanilla_model(input_shape, n_classes)
            else:
                self.bypass_model(input_shape, n_classes)

            return self.model

    unique_name = f'net_saved/Snet'  # Python equivalent of num2str(k)
    reget_flag = 0
    # Directory to save the network
    sav_folder = 'net_saved'
    if not os.path.exists(sav_folder):
        os.makedirs(sav_folder)
    # Name of the file to save the model
    sav_name = f'net_saved/Snet.h5'
    # Check if the file exists or if reget_flag is set to 1
    if not os.path.exists(os.path.join(sav_name)) or reget_flag == 1:
        tr_data, tr_lab, tst_data, tst_lab = X_train, Y_train, X_test, Y_test
        target = np.concatenate((tr_lab, tst_lab), axis=0)
        ln = len(set(Y_train.flatten()))
        xx = X_train.shape[0]
        snet = SqueezeNet()
        model = snet.build_model(n_classes=1, choice='vanilla')
        model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
        tr_data = np.resize(tr_data, (xx, 32, 32, 3))
        tr_lab = np.resize(tr_lab, (xx, 1))
        tr_data = np.asarray(tr_data, dtype=np.float32)
        tr_lab = np.asarray(tr_lab, dtype=np.float32)
        model.fit(tr_data, tr_lab, batch_size=64, epochs=1, verbose=1)
        tst_data = np.resize(tst_data, (X_test.shape[0], 32, 32, 3))
        y_pred = model.predict(tst_data)
        y_pred = y_pred.argmax(axis=-1)
        model.summary()
        model.save(sav_name)
        return y_pred
    else:
        model = load_model(sav_name)
        tr_data, tr_lab, tst_data, tst_lab = X_train, Y_train, X_test, Y_test
        tst_data = np.resize(tst_data, (X_test.shape[0], 32, 32, 3))
        tst_data = np.asarray(tst_data, dtype=np.float32)
        y_pred = model.predict(tst_data)
        y_pred = y_pred.argmax(axis=-1)
        return y_pred
from tensorflow.keras.optimizers import Adam
def squeezenet_lr(X_train, Y_train, X_test, Y_test,lr):

    class FireModule(object):
        """
        Fire Module computed as per the SqueezeNet paper
        """

        def __init__(self, layer_number: int, activation: str, kernel_initializer: str) -> None:
            """
            Constructor

            Arguments:
              layer_number       : Index of the Fire Module
              activation         : Activation to be used
              kernel_initializer : Kernel Weight Initialization technique

            Returns:
              None
            """

            self.layer_number = layer_number
            self.activation = activation
            self.kernel_initializer = kernel_initializer

        def build_module(self, fire_input: Layer) -> Layer:
            """
            Build the SqueezeNet

            Arguments:
              fire_input       : Input to Fire Module

            Returns:
              model            : SqueezeNet
            """

            global one, three, five

            output_size = 128 * (1 + (self.layer_number // 2))

            squeeze_1x1_filters = 16 * (1 + (self.layer_number // 2))
            expand_1x1_filters = expand_3x3_filters = output_size // 2

            squeeze_1x1 = Conv2D(name=f'fire_{self.layer_number + 2}_squeeze_1x1',
                                 filters=squeeze_1x1_filters, kernel_size=one, strides=1, padding='valid',
                                 activation=self.activation,
                                 kernel_initializer=self.kernel_initializer)(fire_input)
            expand_1x1 = Conv2D(name=f'fire_{self.layer_number + 2}_expand_1x1',
                                filters=expand_1x1_filters, kernel_size=one, strides=1, padding='valid',
                                activation=self.activation,
                                kernel_initializer=self.kernel_initializer)(squeeze_1x1)
            expand_3x3 = Conv2D(name=f'fire_{self.layer_number + 2}_expand_3x3',
                                filters=expand_3x3_filters, kernel_size=three, strides=1, padding='same',
                                activation=self.activation,
                                kernel_initializer=self.kernel_initializer)(squeeze_1x1)

            fire = Concatenate(name=f'fire_{self.layer_number + 2}')([expand_1x1, expand_3x3])

            return fire

    class SqueezeNet(object):
        """
        SqueezeNet Architecture
        """

        def __init__(self, activation: str = 'relu', kernel_initializer: str = 'glorot_uniform') -> None:
            """
            Constructor

            Arguments:
              activation         : Activation to be used
              kernel_initializer : Kernel Weight Initialization technique

            Returns:
              None
            """

            self.activation = activation
            self.kernel_initializer = kernel_initializer

        def vanilla_model(self, input_shape: tuple = (32, 32, 3), n_classes: int = 2) -> None:
            """
            Vanilla Implementation of SqueezeNet

            Arguments:
              input_shape         : Input Shape of the images
              n_classes           : Number of output classes

            Returns:
              None
            """

            inp = Input(shape=input_shape, name='Input')

            # Conv1 Layer
            conv_1 = Conv2D(name="Conv_1",
                            filters=96, kernel_size=seven, strides=2, padding='same', activation=self.activation,
                            kernel_initializer=self.kernel_initializer)(inp)
            maxpool_1 = MaxPool2D(name="MaxPool_1",
                                  pool_size=three, strides=2)(conv_1)

            # Fire 2-4
            fire_2 = FireModule(layer_number=0, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(maxpool_1)
            fire_3 = FireModule(layer_number=1, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(fire_2)
            fire_4 = FireModule(layer_number=2, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(fire_3)

            # Max Pool after Fire4 Module
            maxpool_2 = MaxPool2D(name="MaxPool_2",
                                  pool_size=three, strides=2)(fire_4)

            # Fire 5-8
            fire_5 = FireModule(layer_number=3, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(maxpool_2)
            fire_6 = FireModule(layer_number=4, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(fire_5)
            fire_7 = FireModule(layer_number=5, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(fire_6)
            fire_8 = FireModule(layer_number=6, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(fire_7)

            # Max Pool after Fire8 Module
            maxpool_3 = MaxPool2D(name="MaxPool_3",
                                  pool_size=three, strides=2)(fire_8)

            fire_9 = FireModule(layer_number=7, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(maxpool_3)

            # Dropout
            dropout = Dropout(0.5, name="Dropout")(fire_9)

            # Conv10 layer
            conv_10 = Conv2D(name="Conv_10",
                             filters=1000, kernel_size=one, strides=1, padding='valid', activation=self.activation,
                             kernel_initializer=self.kernel_initializer)(dropout)
            gap_11 = GlobalAveragePooling2D()(conv_10)

            # Add Dense(n_classes) and ouput == Dense layer
            out = Dense(1, activation='linear')(gap_11)

            self.model = Model(inputs=inp, outputs=out)

        def bypass_model(self, input_shape: tuple = (32, 32, 3), n_classes: int = 2) -> None:
            """
            Residual Inspired Bypass Implementation of SqueezeNet

            Arguments:
              input_shape         : Input Shape of the images
              n_classes           : Number of output classes

            Returns:
              None
            """

            inp = Input(shape=input_shape, name='Input')

            # Conv1 Layer
            conv_1 = Conv2D(name="Conv_1",
                            filters=96, kernel_size=seven, strides=2, padding='same', activation=self.activation,
                            kernel_initializer=self.kernel_initializer)(inp)
            maxpool_1 = MaxPool2D(name="MaxPool_1",
                                  pool_size=three, strides=2)(conv_1)

            # Fire 2-4
            fire_2 = FireModule(layer_number=0, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(maxpool_1)
            fire_3 = FireModule(layer_number=1, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(fire_2)
            bypass_1 = Add(name="Bypass_1")([fire_2, fire_3])
            fire_4 = FireModule(layer_number=2, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(bypass_1)

            # Max Pool after Fire4 Module
            maxpool_2 = MaxPool2D(name="MaxPool_2",
                                  pool_size=three, strides=2)(fire_4)

            # Fire 5-8
            fire_5 = FireModule(layer_number=3, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(maxpool_2)
            bypass_2 = Add(name="Bypass_2")([maxpool_2, fire_5])
            fire_6 = FireModule(layer_number=4, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(bypass_2)
            fire_7 = FireModule(layer_number=5, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(fire_6)
            bypass_3 = Add(name="Bypass_3")([fire_6, fire_7])
            fire_8 = FireModule(layer_number=6, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(bypass_3)

            # Max Pool after Fire8 Module
            maxpool_3 = MaxPool2D(name="MaxPool_3",
                                  pool_size=three, strides=2)(fire_8)

            fire_9 = FireModule(layer_number=7, activation=self.activation,
                                kernel_initializer=self.kernel_initializer).build_module(maxpool_3)
            bypass_4 = Add(name="Bypass_4")([maxpool_3, fire_9])

            # Dropout
            dropout = Dropout(0.5, name="Dropout")(bypass_4)

            # Conv10 layer
            conv_10 = Conv2D(name="Conv_10",
                             filters=1000, kernel_size=one, strides=1, padding='valid', activation=self.activation,
                             kernel_initializer=self.kernel_initializer)(dropout)
            gap_11 = GlobalAveragePooling2D()(conv_10)

            out = Dense(4, activation='softmax')(gap_11)

            self.model = Model(inputs=inp, outputs=out)

        def build_model(self, input_shape: tuple = (32, 32, 3), n_classes: int = 4, choice: str = 'vanilla') -> Model:
            """
            Build SqueezeNet

            Arguments:
              input_shape         : Input Shape of the images
              n_classes           : Number of output classes
              choice              : Type of architecture (vanilla/bypass)
            Returns:
              model               : SqueezeNet Model
            """

            if choice == "vanilla":
                self.vanilla_model(input_shape, n_classes)
            else:
                self.bypass_model(input_shape, n_classes)

            return self.model

    unique_name = f'net_saved/Snet_lr'  # Python equivalent of num2str(k)
    reget_flag = 0
    # Directory to save the network
    sav_folder = 'net_saved'
    if not os.path.exists(sav_folder):
        os.makedirs(sav_folder)
    # Name of the file to save the model
    sav_name = f'net_saved/Snet_lr.h5'
    # Check if the file exists or if reget_flag is set to 1
    if not os.path.exists(os.path.join(sav_name)) or reget_flag == 1:
        tr_data, tr_lab, tst_data, tst_lab = X_train, Y_train, X_test, Y_test
        target = np.concatenate((tr_lab, tst_lab), axis=0)
        ln = len(set(Y_train.flatten()))
        xx = X_train.shape[0]
        snet = SqueezeNet()
        model = snet.build_model(n_classes=1, choice='vanilla')
        model.compile(optimizer='adam',
                      loss='mean_squared_error',
                      metrics=['mean_absolute_error'])
        # model.summary()
        tr_lab_init = tr_lab
        tr_lab = to_categorical(tr_lab)
        tr_data = np.resize(tr_data, (xx, 32, 32, 3))
        tr_lab = np.resize(tr_lab, (xx, ln))
        model.fit(tr_data, tr_lab, batch_size=64, epochs=1, verbose=1)
        tst_data = np.resize(tst_data, (X_test.shape[0], 32, 32, 3))
        y_pred = model.predict(tst_data)
        y_pred = y_pred.argmax(axis=-1)
        model.summary()
        model.save(sav_name)
        return y_pred
    else:
        model = load_model(sav_name)
        tr_data, tr_lab, tst_data, tst_lab = X_train, Y_train, X_test, Y_test
        tst_data = np.resize(tst_data, (X_test.shape[0], 32, 32, 3))
        y_pred = model.predict(tst_data)
        y_pred = y_pred.argmax(axis=-1)
        return y_pred
